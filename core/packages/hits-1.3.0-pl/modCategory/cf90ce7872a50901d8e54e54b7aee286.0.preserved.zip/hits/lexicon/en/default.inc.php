<?php
$_lang['hit'] = 'Hit';
$_lang['hits'] = 'Hits';
$_lang['hits.desc'] = 'Hits for MODX tracks pagehits with a punch.';